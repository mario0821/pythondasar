#hello_wolrd.py

import PySimpleGUI as sg

sg.Window( title="hello world", layout={[]}, margins=(100, 50)).read()
