import tkinter as tk 
from tkinter import ttk 
from tkinter.messagebox import showinfo

window = tk.tK()
window.configure(bg="white")
window.geometry ("300x200")
window.resizable(False,False)
window.title("sapa")

NAMA_DEPAN = tk.StringVar()
NAMA_BELAKANG = tk.StringVar()

def tombol_click():
    pesan=f"hello {NAMA_DEPAN.get()} {NAMA_BELAKANG.get()}, have a nice day"
    showinfo(title="hi", message=pesan)

    input_frame = ttk.frame(window)
    input_frame.pack(padx=10, pady=10, fill="x", expand=True)

    nama_depan_label = ttk.label(input_frame, text="NAMA_DEPAN:")
    nama_depan_label.pack(padx=10, fill="x", expand=True)

    nama_depan_entry = ttk.Entry(input_frame, textvariable=NAMA_DEPAN)
    nama_depan_entry.pack(padx=10, fill="x", expand=True)

    nama_belakang_label = ttk.label(input_frame, textvariable="NAMA_BELAKANG:")
    nama_belakang_label.pack(padx=10, fill="x", expand=True)

    nama_belakang_entry = ttk.Entry(input_frame, textvariable=NAMA_DEPAN)
    nama_belakang_entry.pack(padx=10, fill="x", expand=True)

    tombol = ttk.Button(input_frame, text="sapa!", command=tombol_click)
    tombol.pack(fil='x', expand=True,padx=10,pady=10)

    window.mainloop () 




