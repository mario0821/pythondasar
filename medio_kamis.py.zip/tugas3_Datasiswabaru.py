class Siswa:
    def _init_(self, nama, nis, kelas):
        self.nama = nama
        self.nis = nis
        self.kelas = kelas

# Inisialisasi daftar siswa
data_siswa = []

# Fungsi untuk menambahkan data siswa baru
def tambah_siswa():
    nama = input("Masukkan nama siswa: ")
    nis = input("Masukkan NIS siswa: ")
    kelas = input("Masukkan kelas siswa: ")
    
    siswa = Siswa(nama, nis, kelas)
    data_siswa.append(siswa)
    print(f"Data siswa {nama} berhasil ditambahkan.")

# Fungsi untuk menampilkan daftar siswa
def tampilkan_daftar_siswa():
    print("\nDaftar Siswa:")
    for i, siswa in enumerate(data_siswa, start=1):
        print(f"Data Siswa {i}:")
        print(f"Nama: {siswa.nama}")
        print(f"NIS: {siswa.nis}")
        print(f"Kelas: {siswa.kelas}")
        print()

# Fungsi utama
def main():
    while True:
        print("\nMenu:")
        print("1. Tambah Siswa")
        print("2. Tampilkan Daftar Siswa")
        print("3. Keluar")

        pilihan = input("Pilih menu: ")

        if pilihan == "1":
            tambah_siswa()
        elif pilihan == "2":
            tampilkan_daftar_siswa()
        elif pilihan == "3":
            break
        else:
            print("Pilihan tidak valid. Silakan pilih lagi.")

if __name__ == "__main__":
    main()