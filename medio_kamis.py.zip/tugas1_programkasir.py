# Inisialisasi daftar barang dan harga
daftar_barang = {"produk 1": 10, "produk 2": 15, "produk 3": 20, "produk 4": 25}

# Inisialisasi keranjang belanja
keranjang = []

# Fungsi untuk menambahkan barang ke keranjang
def tambah_barang():
    produk = input("Masukkan nama produk: ")
    if produk in daftar_barang:
        keranjang.append((produk, daftar_barang[produk]))
        print(f"{produk} ditambahkan ke keranjang.")
    else:
        print("Produk tidak ditemukan.")

# Fungsi untuk menghitung total belanja
def hitung_total():
    total = sum(harga for _, harga in keranjang)
    return total

# Fungsi utama
def main():
    while True:
        print("Daftar Barang:")
        for barang, harga in daftar_barang.items():
            print(f"{barang}: ${harga}")

        print("\nMenu:")
        print("1. Tambah Barang ke Keranjang")
        print("2. Hitung Total Belanja")
        print("3. Keluar")

        pilihan = input("Pilih menu: ")

        if pilihan == "1":
            tambah_barang()
        elif pilihan == "2":
            total = hitung_total()
            print(f"Total belanja: ${total}")
        elif pilihan == "3":
            break
        else:
            print("Pilihan tidak valid. Silakan pilih lagi.")

if __name__ == "__main__":
    main()