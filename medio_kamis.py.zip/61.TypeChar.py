import PySimpleGUI as sg

sg.theme('Bluepurple')

layout = [[sg.text('your typed chars appear here:'), sg.text(size=(15,1), key='-OUTPUT-')]
          [sg.Input(key='-IN-')]
          [sg.Button('show'), sg.Button('Exit')]] 

window = sg.window('pattern 2', layout)

while True: 
    event, values = window.read()
    print(event, values)
    if event == sg.WIN_CLOSED or event == 'exit':
        break
    if event == 'show':

        window['-OUTPUT-']. update(values['-IN-'])

window.close()