import tkinter as tk
root = tk.Tk()
label = tk.label(root, text="label 1")
label.pack()

Button = tk.Button(root, text="centang 1")
Button.pack()

checkbox = tk.CheckButton(root, text="centang 1")
checkbox.pack()
root.mainLoop()
