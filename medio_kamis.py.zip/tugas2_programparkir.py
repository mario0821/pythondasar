# Inisialisasi jumlah slot parkir
jumlah_slot = 10

# Inisialisasi daftar slot parkir yang tersedia
slot_parkir = [False] * jumlah_slot

# Fungsi untuk menampilkan status parkir
def tampilkan_status_parkir():
    print("\nStatus Parkir:")
    for i, status in enumerate(slot_parkir, start=1):
          print(f"Slot {i}: Terisi")
    else:
            print(f"Slot {i}: Kosong")

# Fungsi untuk parkir kendaraan
def parkir_kendaraan():
    for i, status in enumerate(slot_parkir, start=1):
        if not status:
            slot_parkir[i - 1] = True
            print(f"Kendaraan berhasil diparkir di slot {i}.")
            break
    else:
        print("Maaf, semua slot parkir penuh.")

# Fungsi untuk mengeluarkan kendaraan
def keluarkan_kendaraan():
    nomor_slot = int(input("Masukkan nomor slot parkir yang ingin dikeluarkan: "))
    if 1 <= nomor_slot <= jumlah_slot:
        if slot_parkir[nomor_slot - 1]:
            slot_parkir[nomor_slot - 1] = False
            print(f"Kendaraan berhasil dikeluarkan dari slot {nomor_slot}.")
        else:
            print(f"Slot {nomor_slot} sudah kosong.")
    else:
        print("Nomor slot tidak valid.")

# Fungsi utama
def main():
    while True:
        print("\nMenu:")
        print("1. Tampilkan Status Parkir")
        print("2. Parkir Kendaraan")
        print("3. Keluarkan Kendaraan")
        print("4. Keluar")

        pilihan = input("Pilih menu: ")

        if pilihan == "1":
            tampilkan_status_parkir()
        elif pilihan == "2":
            parkir_kendaraan()
        elif pilihan == "3":
            keluarkan_kendaraan()
        elif pilihan == "4":
            break
        else:
            print("Pilihan tidak valid. Silakan pilih lagi.")

if __name__ == "__main__":
    main()