#membuat function
def my_function():
    print("hello from a function")

    #memanggil function
    my_function()