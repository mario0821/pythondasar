

def my_function(fname):
    print(fname + " Refsnens")

my_function("Email")
my_function("Tobias")
my_function("Linus")