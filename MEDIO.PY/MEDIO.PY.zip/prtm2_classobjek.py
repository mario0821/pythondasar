#membuat class
class MyClass:
    x = 5

#Membuat objek
p1 = MyClass()

#Mencetak nilai var x pada class MyClass
print(p1.x)