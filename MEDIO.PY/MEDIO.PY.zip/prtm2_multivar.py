#Many values to multiple variables
x, y, z = "Orange", "Banana", "Cherry"
print(x)
print(y)
print(z)


#One Value to Multiple Variables
x = y = z = "Orange"
print(x)
print(y)
print(z)